create definer = root@localhost trigger GenerateNewID
    before insert
    on ab_resume
    for each row
BEGIN
    DECLARE currentYear INT;
    DECLARE currentCount INT;

    SET currentYear = YEAR(CURDATE()) - 2000;  -- 获取当前年份的后两位
    SET currentCount = 1;

    -- 查找当前年份的最大编号
    SELECT MAX(id % 10000) INTO currentCount
    FROM ab_resume
    WHERE id >= currentYear * 10000;

    -- 如果没有记录，将计数器重置为1
    IF currentCount IS NULL THEN
        SET currentCount = 1;
    ELSE
        SET currentCount = currentCount + 1;
    END IF;

    -- 生成新的编号
    SET NEW.id = currentYear * 10000 + currentCount;
END;

